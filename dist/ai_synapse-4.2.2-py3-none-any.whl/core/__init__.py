# Core AI Engine modules
